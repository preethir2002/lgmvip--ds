# Get-Sketch-from-image
This is a python program to convert image to sketch.
