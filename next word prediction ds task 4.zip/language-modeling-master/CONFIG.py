number_of_words = 3
batch_size = 200
hidden_size = 1500
num_epochs = 80
learning_rate = 0.001
learning_rate_decay = 0
